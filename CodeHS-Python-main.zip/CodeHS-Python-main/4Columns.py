#move to the starting position
penup()
backward(100)
left(90)
backward(200)

#draw first line
pendown()
forward(400)
penup()

# Move into position for middle line
right(90)
forward(100)
right(90)

# Draw second line
pendown()
forward(400)
penup()

# Move into position for last line
left(90)
forward(100)
left(90)

# Draw third line
pendown()
forward(400)