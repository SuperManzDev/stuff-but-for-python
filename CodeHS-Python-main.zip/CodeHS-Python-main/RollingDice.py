for index1 in range(6):
    for index2 in range(6):
        print str(index1 + 1) + ", " + str(index2 + 1)