speed(10)

for i in range(7):
    circle(20 * (i + 1), 360, i)