print "This is a line of text!"
print "Here's another line."