has_dog = False

print "Do I have to walk the dog?"

# If has_dog is True, the print on line 8
# happens.
if has_dog:
    print "Yup."

# Otherwise, the print on line 12 happens.
else:
    print "Nope. I don't have a dog!"