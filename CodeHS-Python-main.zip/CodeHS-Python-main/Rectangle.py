# draw the bottom of the rectangle
forward(50)
left(90)

# draw the right of the rectangle
forward(100)
left(90)

# draw the top of the rectangle
forward(50)
left(90)

# draw the left of the rectangle

forward(100)
left(90)