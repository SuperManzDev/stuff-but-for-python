length = 10
width = 5

area = length * width
perimeter = length * 2 + width * 2
print(area)
print(perimeter)