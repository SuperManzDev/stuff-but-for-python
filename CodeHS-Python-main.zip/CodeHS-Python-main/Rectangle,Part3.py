length = int(input("What is the length? "))
width = int(input("What is the width? "))

area = length * width
perimeter = length * 2 + width * 2

print("Area = " + str(area))
print("perimeter = " + str(perimeter))