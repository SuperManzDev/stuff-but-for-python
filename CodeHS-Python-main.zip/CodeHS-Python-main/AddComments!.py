
#This is a comment
first_name = input("Enter your first name: ")
middle_name = input("Enter your middle name: ")
last_name = input("Enter your last name: ")

"""
This is also comment
"""

full_name = first_name + " " + middle_name + " " + last_name
print full_name