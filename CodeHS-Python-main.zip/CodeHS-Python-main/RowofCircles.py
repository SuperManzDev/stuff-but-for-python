penup()
backward(200)
forward(10)
for i in range(20):
    pendown()
    circle(10)
    penup()
    forward(20)