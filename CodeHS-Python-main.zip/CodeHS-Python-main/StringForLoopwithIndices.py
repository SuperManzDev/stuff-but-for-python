"""
This program uses a for loop to print out each letter in the string on its
own line using indicies.
"""

my_string = "hello"
for i in range(len(my_string)):
    print my_string[i]