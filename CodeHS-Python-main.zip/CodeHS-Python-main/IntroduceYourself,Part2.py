name = "IBXCODECAT"
age = 16
print("Hi my name is " + name + ". I am " + str(age) + " years old!")