length = 10
width = 5

area = length * width
perimeter = length * 2 + width * 2

print("Area = " + str(area))
print("perimeter = " + str(perimeter))