speed(5)

penup()
setposition(-50,-100)

for i in range (2):
    pendown()
    circle(50)
    penup()
    forward(100)

setposition(-50,0)

for i in range (2):
    pendown()
    circle(50)
    penup()
    forward(100)