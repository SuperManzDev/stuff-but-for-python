# This function prints a greeting
def greeting():
    print "Hi there!"
    print "Nice to meet you!"

# Call the function to run
greeting()