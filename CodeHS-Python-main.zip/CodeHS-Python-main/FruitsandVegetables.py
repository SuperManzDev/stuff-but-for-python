my_list = ["broccoli", "apple", "zucchini", "rambutan", "grapefruit"]

my_list.remove("grapefruit")
my_list.sort()
my_list.reverse()


print my_list