"""
This program shows how packing can use variables as elements in a list.
"""

x = 1
y = 2
z = 3
my_list = [x, y, z]

print my_list