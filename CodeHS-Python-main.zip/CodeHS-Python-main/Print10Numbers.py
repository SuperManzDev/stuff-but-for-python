"""
This program prints ten numbers - 0 through 9.
"""

# Inside the for loop, we can treat i like a normal integer variable.

for i in range(10):
    print i