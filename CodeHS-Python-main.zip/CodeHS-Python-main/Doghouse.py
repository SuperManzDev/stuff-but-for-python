my_string = "doghouse"

# print "h" here
print my_string[3]

# print "e" here
print my_string[7]

# print "e" using a second index value
print my_string[-1]