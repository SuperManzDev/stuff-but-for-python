"""
This program uses a for loop to print out each letter in the string on its
own line.
"""

my_string = "hello"
for letter in my_string:
    print letter