userInput = input("say something: ")

def add_enthusiasm(text):
    return text.upper()
    
print "You mean " + add_enthusiasm(userInput) + "!"