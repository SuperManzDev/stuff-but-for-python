# increase the speed of the turtle, I hate waiting.
speed(5)

# loop six times because a hbexigon has 6 sides

for x in range(6):
    
    #must move forward 50 pixels acording to instructins
    forward(50)
    
    ''' 
    # the of all the angles of a hexigon is 360, so each angle
    # must be at 360 / divided by how many angles there are in
    # a hexigon. There are six so we turn left(360 / 6). The
    # left command is a method and we input the equation into
    # that method!
    '''
    
    left(360 / 6)