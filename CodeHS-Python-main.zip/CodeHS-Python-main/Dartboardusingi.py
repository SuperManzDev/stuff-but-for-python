for i in range(4):
    circle((i + 1) * 25)
    penup()
    left(90)
    backward(25)
    right(90)
    pendown()