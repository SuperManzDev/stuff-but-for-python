x = int(input("Enter your age"))

print("You will need this many candles for your birthday cake")
print(x + 1)