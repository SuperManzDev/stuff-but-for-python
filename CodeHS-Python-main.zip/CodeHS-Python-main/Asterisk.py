speed(5)

left(30)
for i in range(6):
    forward(100)
    backward(100)
    left(60)