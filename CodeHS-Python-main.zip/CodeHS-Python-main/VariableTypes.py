print type(2)
print type("Hi")

print "-----"

pi = 3.14
initial = "c"

print type(pi)
print type(initial)

#MY STUFF

print type(False)
print type("YO!")
print type(2.5)
print type(1)

while(pi == 3.14):
    #The input method is always a string
    print type(input("Enter Something: "))