"""
This program prints a variable saved in a function.
"""

def print_something():
    x = 10
    print x

print_something()