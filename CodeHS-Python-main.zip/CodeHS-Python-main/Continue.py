# This for loop only prints 0 through 4 and 6 through 9.
for i in range(10):
    if i == 5:
        continue
    print i