"""
This program will draw an octagon where each side is a different color.
"""

speed(5)
pensize(5)

# Draw one side of shape, then change color and turn 60 degrees before
# drawing next line. Continue for 8 lines to complete hexagon.
color("red")
forward(50)
left(45)
color("orange")
forward(50)
left(45)
color("yellow")
forward(50)
left(45)
color("green")
forward(50)
left(45)
color("blue")
forward(50)
left(45)
color("indigo")
forward(50)
left(45)
color("purple")
forward(50)
left(45)
color("pink")
forward(50)