
#order_num = (name, burgers, hotdogs)
order_1 = ("Lee", 0, 2)
order_2 = ("Tamia", 1, 0)
order_3 = ("Edward", 1, 1)

# Your code here...

print "You need to buy " + str(order_1[1] + order_2[1] + order_3[1]) + " burgers"
print "You need to buy " + str(order_1[2] + order_2[2] + order_3[2]) + " hotdogs"