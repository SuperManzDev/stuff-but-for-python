instrument = "kazoo"
age = str(7)

print "I have played the " + instrument + " since I was " + age + " years old."