"""
This program takes two values and prints their sum.
"""

def add_nums():
    num1 = 5
    num2 = 6
    print num1 + num2
    
add_nums()