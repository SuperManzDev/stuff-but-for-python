penup()
backward(200)

for i in range (40):
    pendown()
    forward(5)
    penup()
    forward(5)