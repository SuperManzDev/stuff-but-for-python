"""
This program uses the sort method on a list to change the list such that the
elements are placed in order from least to greatest.
"""

my_list = [1, 4, 2, -4, 10, 0]
print my_list

my_list.sort()
print my_list