penup()
backward(200)

pendown();
forward(50);

penup();
forward(50)

pendown();
forward(50)

penup();
forward(50)

pendown();
forward(50)

penup();
forward(50)

pendown();
forward(50)

penup();
forward(50)