"""
This program shows how range can be used in a list comprehension to make a
list out of a range.
"""

numbers = [x for x in range(5)]
print numbers