total = 0

for i in range(10):
    next = int(input("Enter a number: "))
    total = total + next

print "Sum: " + str(total)