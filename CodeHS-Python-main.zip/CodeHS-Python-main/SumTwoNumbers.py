def add(num1, num2):
    return num1 + num2
    
print add(1, 2)