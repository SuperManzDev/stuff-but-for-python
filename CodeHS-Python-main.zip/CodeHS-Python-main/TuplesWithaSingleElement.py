"""
This program shows how to create a tuple with a single element.
"""

# This just creates an integer...
x = (3)
print x
print type(x)

# This creates a tuple
x = (3,)
print x
print type(x)