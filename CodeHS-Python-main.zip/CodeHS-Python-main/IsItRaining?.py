is_raining = True

if is_raining:
    print("I'm going to dance in the rain!")
else:
    print("I'm going to dance in the sun!")