def String(string, prints):
    ans = string * prints
    print ans
    
String("Yo to the yo-yo! ", 12)