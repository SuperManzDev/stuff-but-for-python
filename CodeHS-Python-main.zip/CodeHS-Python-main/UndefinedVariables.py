a = int(10)
c = int(20)
b = c
d = a + b
e = 80

print a
print b
print c
print d
print e