"""
This program uses the find method which returns the first index at which
a particular string is found within a string, or -1 if it is not found.
"""

s = "abra kadabra alakazam"
print s
print s.find("a")
print s.find("kadabra")
print s.find("q")