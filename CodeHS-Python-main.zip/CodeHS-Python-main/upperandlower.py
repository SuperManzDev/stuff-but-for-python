"""
This program turns a string into all capital or all lowercase letters.
"""

first_string = "hello"
second_string = first_string.upper()
third_string = second_string.lower()

print first_string
print second_string
print third_string