author_name = ("Martin", "Luther", "King, Jr.")

print author_name[2] + ", " + author_name[0] + " " + author_name[1]