def PrintTotal():
    num2 = int(input("Please enter a number: "))
    tot = num1 + num2
    
    print str(num1) + " plus " + str(num2) + " is equal to: " + str(tot)

num1 = 10

PrintTotal()