number = float(input("Please enter a number: "))

if number < 0:
    print("Negative")
elif number > 0:
    print("Positive")
else:
    print("Zero")