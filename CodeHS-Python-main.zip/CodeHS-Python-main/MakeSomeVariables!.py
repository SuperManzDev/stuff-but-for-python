i = int(1)
s = str("jojo")

print i
print s