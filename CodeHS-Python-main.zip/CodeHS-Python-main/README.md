# CodeHS
A collection of my CodeHS work from virtual school in 2021. My school account will be deleted, so it made sense to post it here.
