# This function takes a single parameter and prints it.

def print_number(x):
    print x

print_number(12)
print_number("dog")