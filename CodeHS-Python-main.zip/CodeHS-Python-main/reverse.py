"""
This program uses the reverse method to change a list such that it is in the
reverse order that it was in. Note that it does NOT put it in reverse sorted
order (unless the list was ALREADY in sorted order).
"""

my_list = [1, 4, 2, -4, 10, 0]
print my_list

my_list.reverse()
print my_list