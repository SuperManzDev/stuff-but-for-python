"""
This example prints a list of the first five square numbers, staring at 1.
"""

numbers = [x * x for x in range(1, 6)]
print numbers