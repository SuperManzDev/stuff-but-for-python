name = input("Enter your name: ")

print "Your name has " + str(len(name)) + " letters."