def Mult(num1, num2):
    ans = num1 * num2
    print ans
    
Mult(1, 5)