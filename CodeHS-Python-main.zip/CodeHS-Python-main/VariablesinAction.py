greeting = "Hi there!"
num = 3
value = float(num)

print greeting
print num
print value