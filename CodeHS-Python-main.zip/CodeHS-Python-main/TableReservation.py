reservation_name = "Bob"

name = input("Please enter your name: ")

if reservation_name == name:
    print "Right this way!"
else:
    print "Sorry, we don't have a reservation under that name."