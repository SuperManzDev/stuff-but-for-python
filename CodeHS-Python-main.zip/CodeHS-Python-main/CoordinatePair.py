x = int(input('enter x coord>>>'))
y = int(input('enter y coord>>>'))

coord = (x, y)

print coord