def add_one(num):
    return num + 1

print add_one(32)