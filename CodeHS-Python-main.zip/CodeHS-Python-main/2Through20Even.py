number = 0

while(number < 20):
    number = number + 2
    print number