has_dog = True

print "Do I have to walk the dog?"

# The print on line 8 ONLY happens if
# hasDog is True.
if has_dog:
    print "Yup, I sure do!"