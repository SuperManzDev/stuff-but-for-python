#this is a single line coment
"""
This is a
multiline coment
#single line coments are concidered multiline coments within
"""
#""" multiline coments are concidered single line coments """

circle(35)
forward(40)

circle(35)
forward(40)

circle(35)
forward(40)

circle(35)
forward(40)

circle(35)
forward(40)