needs_water = True
needs_to_be_repotted = False

print "Needs water: " + str(needs_water)
print "Needs to be repotted: " + str(needs_to_be_repotted)