name = input("What is your name: ")

print list(name)