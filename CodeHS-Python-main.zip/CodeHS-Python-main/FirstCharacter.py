def first_character(chars):
    return chars[0]
def all_but_first_character(chars):
    return chars[1:]
    
print first_character("hello")
print all_but_first_character("hello")