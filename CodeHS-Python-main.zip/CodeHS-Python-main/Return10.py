# This function returns the number 10. Wherever it is used, Python
# effectively replaces it with the number 10, similar to how Python
# replaces 3 + 4 with the number 7.
def return_ten():
    return 10

print return_ten()

x = return_ten()
print x + 1