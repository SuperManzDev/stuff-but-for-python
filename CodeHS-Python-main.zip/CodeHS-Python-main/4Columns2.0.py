#move to the start pos
penup()
backward(100)
left(90)
backward(200)

#execut4e this

for x in range(3):
    pendown()
    forward(400)
    penup()
    backward(400)
    right(90)
    forward(100)
    left(90)