print "Hello my name is IBXCODECAT"
print "I like programming and I am a game dev"