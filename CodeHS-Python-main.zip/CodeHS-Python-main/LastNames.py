names = [
    "Maya Angelou",
    "Chimamanda Ngozi Adichie",
    "Tobias Wolff",
    "Sherman Alexie",
    "Aziz Ansari"
]

print [name.split()[-1] for name in names]