# Here's a function that has a parameter and a return value. It takes the
# parameter and returns the negative of it.
def negate(x):
    return -x

print negate(5)

x = negate(-4)
print x