# Can you guess what this program prints?
x = 5
y = 5

while x > 5 or y < 10:
    print x
    print y
    
    x = 15 - x
    y = y + 2