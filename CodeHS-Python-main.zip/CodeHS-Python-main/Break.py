# This for loop only prints 0 through 4.
for i in range(10):
    if i == 5:
        break
    print i