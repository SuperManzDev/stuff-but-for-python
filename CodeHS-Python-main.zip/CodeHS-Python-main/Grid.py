"""
This program show how the multiplication operator can be used on lists! It
takes whatever is in the list and repeats it the specified number of times.
"""

my_grid = []

for i in range(8):
    my_grid.append([0] * 8)

print my_grid