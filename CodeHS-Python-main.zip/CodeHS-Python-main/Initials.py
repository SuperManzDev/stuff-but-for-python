FirstName = input("Please enter your first name: ")
LastName = input("Please enter your last name: ")

print "Initials: " + FirstName[0] + "." + LastName[0] + "."